////////////////////////////////////////////////////////////////////////
Instruction to setup the plugin and templates, shortcodes and Menu items
////////////////////////////////////////////////////////////////////////

#######
Step 1
#######

Install the plugin and Under the settings menu go to the OpenAI menu 
1- Add chatGPT API 
2- Add Services

#######
Step 2
#######

3- Install the Elementor theme and Elementor Page Builder plugin
4- Under the Templates Menu go to the Theme Builder Create template and assign the Singular Page "Industry" and Design the page
5- Use the shortcode to fetch the related Service and Related location posts "[fetch_related_industry]"
6- Use the shortcode to fetch the Contact Form "[custom_contact_form]"

#######
Step 3
#######

7- Under the Templates menu go to the Theme Builder and create another template and assign the Archive page and select post type "Industry" and design the page
8- Use the shortcode to fetch the Hierarchical Locations to the related service "[related_locations_by_service]"

#######
Step 4
#######

9- Under the Settings menu go to the OpenAI Location Generator and generate the content and Create the post.

All these steps please follow carefully and you will get the posts 